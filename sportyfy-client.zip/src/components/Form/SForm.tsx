import React, { ReactNode, useImperativeHandle } from "react";
import { FormProvider, SubmitHandler, useForm } from "react-hook-form";

interface formConfig {
  defaultValues?: Record<string, any>;
  resolver?: any;
}

interface IProps extends formConfig {
  children: ReactNode;
  onSubmit: SubmitHandler<any>;
  className?: string;
  formRef?: React.MutableRefObject<any>;
}
const SForm = ({
  children,
  onSubmit,
  defaultValues,
  resolver,
  className,
}: IProps) => {
  const formConfig: formConfig = {};


  if (defaultValues) {
    formConfig["defaultValues"] = defaultValues;
  }

  if (resolver) {
    formConfig["resolver"] = resolver;
  }

  const methods = useForm(formConfig);


  const submitHandler = methods.handleSubmit;

 
  return ( 
    <FormProvider {...methods}>
      <form className={className} onSubmit={submitHandler(onSubmit)}>
        {children}
      </form>
    </FormProvider>
  );
};

export default SForm;
